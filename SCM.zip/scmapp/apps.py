from django.apps import AppConfig


class ScmappConfig(AppConfig):
    name = 'scmapp'
